// server.cpp

#include <iostream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <cmath>

#define PORT 8080
#define BUFFER_SIZE 1024

void send_menu(int client_socket) {
    std::string menu =
        "\n"
        "Welcome to TCP Calculator!\n"
        "Choose an operation:\n"
        "1. Addition (+)\n"
        "2. Subtraction (-)\n"
        "3. Multiplication (*)\n"
        "4. Division (/)\n"
        "5. Sine (sin)\n"
        "6. Cosine (cos)\n"
        "7. Tangent (tan)\n"
        "Enter your choice (1-7): ";
    send(client_socket, menu.c_str(), menu.length(), 0);
}

int main() {
    int server_fd, client_socket;
    struct sockaddr_in address;
    socklen_t addrlen = sizeof(address);
    char buffer[BUFFER_SIZE] = {0};

    // Create socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == 0) {
        perror("Socket failed");
        return 1;
    }

    // Bind
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        return 1;
    }

    // Listen
    if (listen(server_fd, 1) < 0) {
        perror("Listen failed");
        return 1;
    }

    std::cout << "Server listening on port " << PORT << "...\n";

    // Accept
    client_socket = accept(server_fd, (struct sockaddr*)&address, &addrlen);
    if (client_socket < 0) {
        perror("Accept failed");
        return 1;
    }

    std::cout << "Client connected.\n";

    // Send menu
    int a = 5;
    while(a--){
        send_menu(client_socket);

        // Receive choice
        memset(buffer, 0, BUFFER_SIZE);
        read(client_socket, buffer, BUFFER_SIZE);
        int choice = atoi(buffer);

        double num1 = 0, num2 = 0, result = 0;
        char response[BUFFER_SIZE];

        // Handle input based on operation
        if (choice >= 1 && choice <= 4) {
            // Arithmetic - needs 2 operands
            send(client_socket, "Enter first number: ", 21, 0);
            memset(buffer, 0, BUFFER_SIZE);
            read(client_socket, buffer, BUFFER_SIZE);
            num1 = atof(buffer);

            send(client_socket, "Enter second number: ", 22, 0);
            memset(buffer, 0, BUFFER_SIZE);
            read(client_socket, buffer, BUFFER_SIZE);
            num2 = atof(buffer);

            switch (choice) {
                case 1: result = num1 + num2; break;
                case 2: result = num1 - num2; break;
                case 3: result = num1 * num2; break;
                case 4:
                    if (num2 == 0) {
                        strcpy(response, "Error: Division by zero.");
                        send(client_socket, response, strlen(response), 0);
                        close(client_socket);
                        close(server_fd);
                        return 0;
                    }
                    result = num1 / num2;
                    break;
            }
        } else if (choice >= 5 && choice <= 7) {
            // Trigonometric - needs 1 operand (in degrees)
            send(client_socket, "Enter angle in degrees: ", 25, 0);
            memset(buffer, 0, BUFFER_SIZE);
            read(client_socket, buffer, BUFFER_SIZE);
            num1 = atof(buffer);

            double radians = num1 * M_PI / 180.0;

            switch (choice) {
                case 5: result = sin(radians); break;
                case 6: result = cos(radians); break;
                case 7: result = tan(radians); break;
            }
        } else {
            strcpy(response, "Invalid choice.");
            send(client_socket, response, strlen(response), 0);
            close(client_socket);
            close(server_fd);
            return 0;
        }

        // Send result
        snprintf(response, sizeof(response), "Result: %.6f", result);
        send(client_socket, response, strlen(response), 0);
    }
    close(client_socket);
    close(server_fd);
    return 0;
}
