// client.cpp

#include <iostream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[BUFFER_SIZE] = {0};

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation error");
        return 1;
    }

    // Server address
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        perror("Invalid address");
        return 1;
    }

    // Connect
    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection failed");
        return 1;
    }

    // Receive menu
    int a = 5;
    while(a--){
        memset(buffer, 0, BUFFER_SIZE);
        read(sock, buffer, BUFFER_SIZE);
        std::cout << buffer;

        // Send choice
        std::string input;
        std::getline(std::cin, input);
        send(sock, input.c_str(), input.size(), 0);

        int choice = std::stoi(input);

        if (choice >= 1 && choice <= 4) {
            // Receive and respond to: "Enter first number"
            memset(buffer, 0, BUFFER_SIZE);
            read(sock, buffer, BUFFER_SIZE);
            std::cout << buffer;
            std::getline(std::cin, input);
            send(sock, input.c_str(), input.size(), 0);

            // Receive and respond to: "Enter second number"
            memset(buffer, 0, BUFFER_SIZE);
            read(sock, buffer, BUFFER_SIZE);
            std::cout << buffer;
            std::getline(std::cin, input);
            send(sock, input.c_str(), input.size(), 0);

        } else if (choice >= 5 && choice <= 7) {
            // Receive and respond to: "Enter angle in degrees"
            memset(buffer, 0, BUFFER_SIZE);
            read(sock, buffer, BUFFER_SIZE);
            std::cout << buffer;
            std::getline(std::cin, input);
            send(sock, input.c_str(), input.size(), 0);

        } else {
            std::cerr << "Invalid choice entered. Exiting.\n";
            close(sock);
            return 1;
        }

        // Receive and display result
        memset(buffer, 0, BUFFER_SIZE);
        int valread = read(sock, buffer, BUFFER_SIZE);
        if (valread > 0) {
            std::cout << buffer << std::endl;
        } else {
            std::cerr << "Failed to receive result from server.\n";
        }
    }

    close(sock);
    return 0;
}
