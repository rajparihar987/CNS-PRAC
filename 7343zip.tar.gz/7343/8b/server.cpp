// server.cpp

#include <iostream>
#include <fstream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 2048

int main() {
    int server_fd, client_socket;
    struct sockaddr_in address;
    socklen_t addrlen = sizeof(address);
    char buffer[BUFFER_SIZE] = {0};

    // Create socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == 0) {
        perror("Socket failed");
        return 1;
    }

    // Bind address
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        return 1;
    }

    // Listen
    if (listen(server_fd, 1) < 0) {
        perror("Listen failed");
        return 1;
    }

    std::cout << "Server listening on port " << PORT << "...\n";

    // Accept connection
    client_socket = accept(server_fd, (struct sockaddr*)&address, &addrlen);
    if (client_socket < 0) {
        perror("Accept failed");
        return 1;
    }

    std::cout << "Client connected.\n";

    // Receive filename from client
    memset(buffer, 0, BUFFER_SIZE);
    int valread = read(client_socket, buffer, BUFFER_SIZE);
    if (valread <= 0) {
        std::cerr << "Failed to read filename from client.\n";
        close(client_socket);
        return 1;
    }

    std::string filename = buffer;
    std::cout << "Client requested file: " << filename << std::endl;

    // Open file
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::string notFoundMsg = "File not found.";
        send(client_socket, notFoundMsg.c_str(), notFoundMsg.size(), 0);
        std::cout << "File not found, message sent.\n";
    } else {
        std::string line;
        std::string fileContent;
        while (std::getline(file, line)) {
            fileContent += line + "\n";
        }
        file.close();

        send(client_socket, fileContent.c_str(), fileContent.size(), 0);
        std::cout << "File content sent successfully.\n";
    }

    close(client_socket);
    close(server_fd);
    return 0;
}
