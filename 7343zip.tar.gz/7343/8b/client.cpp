// client.cpp

#include <iostream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 2048

int main() {
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[BUFFER_SIZE] = {0};

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation error");
        return 1;
    }

    // Server address
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        perror("Invalid address");
        return 1;
    }

    // Connect to server
    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection Failed");
        return 1;
    }

    std::cout << "Connected to server.\n";

    // Get filename from user
    std::string filename;
    std::cout << "Enter filename to request: ";
    std::getline(std::cin, filename);

    // Send filename to server
    send(sock, filename.c_str(), filename.size(), 0);

    // Receive file content from server
    memset(buffer, 0, BUFFER_SIZE);
    int valread = read(sock, buffer, BUFFER_SIZE);
    if (valread <= 0) {
        std::cerr << "Failed to receive file content.\n";
    } else {
        std::cout << "\n--- File Content ---\n";
        std::cout << buffer;
        std::cout << "---------------------\n";
    }

    close(sock);
    return 0;
}
